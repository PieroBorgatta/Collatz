# Teoria aggiornata del Debito Gravitazionale nella Mappa di Collatz/Syracuse

## 1. Premessa

La Congettura di Collatz afferma che, partendo da qualsiasi intero positivo \(n\), iterando la funzione:

\[
C(n)=
\begin{cases}
n/2 & \text{se } n \text{ è pari}\\
3n+1 & \text{se } n \text{ è dispari}
\end{cases}
\]

si raggiunge sempre il ciclo finale:

\[
1\rightarrow4\rightarrow2\rightarrow1
\]

Per eliminare i passi pari intermedi, si lavora sulla mappa accelerata di Syracuse, definita sui dispari:

\[
S(n)=\frac{3n+1}{2^{\nu_2(3n+1)}}
\]

Dove:

\[
\nu_2(m)
\]

è il massimo esponente \(a\) tale che \(2^a\) divide \(m\).

La teoria proposta interpreta questa dinamica come un campo discreto in cui:

- \(3n+1\) produce espansione;
- le divisioni per \(2^a\) producono dissipazione;
- i corridoi con molti \(v_2=1\) producono instabilità;
- le confluenze portano le orbite verso tronchi dissipativi comuni.

---

## 2. Potenziale logaritmico

A ogni numero dispari \(n\) associamo un potenziale:

\[
V(n)=\log n
\]

Un passo Syracuse produce approssimativamente:

\[
S(n)\approx n\cdot\frac{3}{2^a}
\]

Dove:

\[
a=\nu_2(3n+1)
\]

La variazione logaritmica approssimata è:

\[
\Delta V\approx \log 3-a\log 2
\]

La soglia critica è quindi:

\[
a>\log_2(3)
\]

Poiché:

\[
\log_2(3)\approx1.5849625
\]

un tratto orbitale è mediamente dissipativo quando:

\[
\overline a>1.5849625
\]

ed è mediamente espansivo quando:

\[
\overline a<1.5849625
\]

---

## 3. Debito gravitazionale

Definiamo il debito gravitazionale dopo \(k\) passi Syracuse come:

\[
D(k)=k\log_2(3)-\sum_{i=1}^{k}a_i
\]

Dove:

\[
a_i=\nu_2(3n_i+1)
\]

Interpretazione:

- se \(D(k)>0\), l'orbita ha accumulato vantaggio espansivo;
- se \(D(k)<0\), la contrazione ha dominato;
- il massimo di \(D(k)\) misura quanto un'orbita riesce a resistere alla gravità.

In questa metafora:

\[
\text{debito}=\text{spinta espansiva}-\text{dissipazione accumulata}
\]

---

## 4. Corridoi 2-adici espansivi

La crescita forte è associata a lunghi tratti con:

\[
a_i=1
\]

Infatti, se \(a_i=1\), allora:

\[
n_{i+1}\approx\frac{3}{2}n_i
\]

quindi il numero cresce.

La condizione:

\[
\nu_2(3n+1)=1
\]

impone:

\[
n\equiv3\pmod4
\]

Sequenze lunghe di \(a_i=1\) impongono classi residue 2-adiche sempre più strette. I rappresentanti minimi seguono:

\[
3,7,15,31,63,127,\dots
\]

cioè:

\[
2^{k+1}-1
\]

Quindi i corridoi più espansivi si avvicinano a \(-1\) in senso 2-adico.

---

## 5. Primo caso estremo: \(n=3.041.127\)

Uno dei numeri più esplosivi trovati sotto 5 milioni è:

\[
n=3.041.127
\]

Risultati:

- massimo valore raggiunto: \(207.572.633.873\);
- rapporto massimo rispetto allo start: circa \(68.255\);
- step del picco: 36;
- primo rientro sotto lo start: 62;
- salti Syracuse totali fino a 1: 132;
- massima sequenza consecutiva di \(v_2=1\): 17;
- media finale \(v_2\): 1,75.

Poiché:

\[
1.75>\log_2(3)
\]

la traiettoria, pur avendo una fase esplosiva, è complessivamente dissipativa.

---

## 6. Autostrada gravitazionale comune

Analizzando i numeri con massimo debito sotto 5 milioni, è emerso un tronco comune:

\[
8.216.025.965
\]

Questo tronco è condiviso da 62 numeri ribelli distinti.

Caratteristiche del tronco:

- valore iniziale: \(8.216.025.965\);
- valore finale: 1;
- salti Syracuse: 63;
- \(v_2\) totale: 133;
- media \(v_2\): 2,111111;
- surplus finale: +33,147362;
- massimo debito: 0.

Il tronco è quindi fortemente dissipativo.

La caduta più violenta del tronco è:

\[
428.885\rightarrow2.513
\]

con:

\[
v_2=9
\]

---

## 7. Struttura a due fasi

I 62 numeri ribelli seguono una dinamica in due fasi.

### Fase 1 — Pre-ingresso

Prima di entrare nel tronco comune, i numeri hanno media \(v_2\) inferiore alla soglia critica.

Valori tipici:

\[
\overline{v_2}\approx1.40-1.46
\]

Poiché:

\[
1.40-1.46<\log_2(3)
\]

questa fase è espansiva.

In questa fase i numeri accumulano debito gravitazionale.

### Fase 2 — Tronco comune

Dopo l'ingresso nel tronco:

\[
8.216.025.965
\]

la media diventa:

\[
\overline{v_2}=2.111111
\]

quindi:

\[
2.111111>\log_2(3)
\]

Il tronco scarica il debito accumulato e porta l'orbita fino a 1.

---

## 8. Albero inverso del tronco

La mappa inversa di Syracuse è data da:

\[
S(n)=m
\]

cioè:

\[
\frac{3n+1}{2^a}=m
\]

Da cui:

\[
n=\frac{m2^a-1}{3}
\]

purché \(n\) sia intero, dispari e positivo.

Costruendo l'albero inverso del nodo:

\[
8.216.025.965
\]

con limite di ricerca pari al valore del root e target sotto 5 milioni, si ottiene:

- nodi totali generati: 116.129;
- nodi sotto 5 milioni: 133;
- membri top-debito attesi: 62;
- membri trovati: 62;
- membri mancanti: 0;
- extra sotto 5 milioni: 71.

Quindi i 62 numeri ribelli sono esattamente un sottoinsieme dei predecessori sotto 5 milioni del tronco comune.

---

## 9. Membri top-debito vs extra

Confrontando i 62 membri top-debito con i 71 extra dello stesso albero inverso:

| Misura | Membri top-debito | Extra |
|---|---:|---:|
| max debt medio | 12,786329 | 11,153815 |
| max ratio medio | 8444,966694 | 2327,773039 |
| entry step medio | 85,000000 | 87,929577 |
| avg \(v_2\) medio | 1,433575 | 1,456776 |
| ratio \(v_2=1\) medio | 0,688817 | 0,680587 |

Interpretazione:

I membri top-debito hanno:

- maggiore densità di \(v_2=1\);
- media \(v_2\) più bassa;
- debito massimo più alto;
- crescita massima molto superiore.

Quindi i rami più pericolosi dell'albero inverso sono quelli che mantengono più a lungo una dinamica espansiva.

---

## 10. Teoria risultante

La teoria può essere formulata così:

> Le orbite di Collatz/Syracuse possono salire solo entrando in corridoi 2-adici sottili caratterizzati da alta densità di valori \(v_2=1\). Questi corridoi accumulano debito gravitazionale, ma tendono a confluire in tronchi comuni dissipativi, dove blocchi con valori \(v_2\) elevati scaricano il debito e portano l'orbita verso 1.

In forma sintetica:

\[
\text{corridoio espansivo}\rightarrow\text{debito}\rightarrow\text{confluenza}\rightarrow\text{tronco dissipativo}
\]

---

## 11. Dalla gravità alla quasi-Lyapunov

Il potenziale semplice:

\[
V(n)=\log n
\]

non basta, perché vede solo la quota locale.

Una discesa sotto il valore iniziale può essere ingannevole: alcuni numeri scendono immediatamente, ma poi entrano in corridoi espansivi con alta densità di \(v_2=1\).

Per questo è stata introdotta una funzione corretta:

\[
H(n)=\log(n)+\lambda D_{\max,80}(n)-\mu C_{\max,80}(n)+\theta P_{\max,80}(n)
\]

Dove:

- \(D_{\max,80}\) misura il massimo debito futuro;
- \(C_{\max,80}\) misura la massima cascata dissipativa futura;
- \(P_{\max,80}\) misura la massima pressione futura del corridoio \(v_2=1\).

---

## 12. Definizione del debito futuro

Per una finestra di 80 passi:

\[
D_{\max,80}(n)=\max_{1\leq k\leq80}\left(k\log_2(3)-\sum_{i=1}^{k}a_i\right)
\]

Questo termine è positivo nella funzione perché un alto debito futuro indica rischio espansivo.

---

## 13. Definizione della cascata dissipativa

Definiamo:

\[
C_{\max,80}(n)=\max_{1\leq k\leq80}\left(\sum_{i=1}^{k}a_i-k\log_2(3)\right)
\]

Questo termine è negativo nella funzione perché una cascata dissipativa futura riduce il rischio.

---

## 14. Definizione della pressione espansiva

Definiamo:

\[
P_{\max,80}(n)=\max_{1\leq k\leq80}\left(\frac{\#\{i\leq k:a_i=1\}}{k}\right)
\]

Questo termine è positivo nella funzione perché un'alta densità futura di \(v_2=1\) indica un corridoio espansivo.

---

## 15. Funzione finale

La candidata empirica finale è:

\[
\boxed{
H(n)=\log(n)+0.28D_{\max,80}(n)-0.03C_{\max,80}(n)+0.30P_{\max,80}(n)
}
\]

Interpretazione:

| Termine | Ruolo fisico |
|---|---|
| \(\log(n)\) | quota/potenziale locale |
| \(D_{\max,80}\) | debito espansivo futuro |
| \(C_{\max,80}\) | cascata dissipativa futura |
| \(P_{\max,80}\) | pressione del corridoio \(v_2=1\) |

Questa funzione non misura solo se un numero è sceso. Misura se è davvero uscito dalla zona espansiva.

---

## 16. Validazione fino a 5 milioni

Sotto 5 milioni, la funzione ha prodotto:

- peggioramenti totali: 76;
- veri ribelli: 59;
- veri ribelli estremi: 14;
- falsi allarmi: 3.

Quindi 73 peggioramenti su 76 corrispondono a casi strutturalmente significativi.

---

## 17. Validazione fino a 20 milioni

Sotto 20 milioni, sui soli dispari:

- numeri analizzati: 9.999.999;
- improved: 1.592.944;
- worsened: 408;
- same: 8.406.647;
- avg log step: 3,491526;
- avg H step: 3,141184;
- max log step: 181;
- max H step: 176;
- worst loss: 133 su \(n=12.826.025\);
- best gain: 80 su \(n=9.138.203\).

Classificazione dei 408 peggioramenti:

- vero ribelle: 297;
- vero ribelle estremo: 64;
- intermedio: 27;
- falso allarme: 20.

Quindi:

\[
361\text{ peggioramenti su }408
\]

sono veri ribelli o ribelli estremi.

---

## 18. Caso estremo principale

Il peggior loss osservato fino a 20 milioni è:

\[
n=12.826.025
\]

con:

- log_step = 1;
- H_step = 134;
- loss = 133;
- max_ratio = 2345,210;
- ratio \(v_2=1\) = 0,679104;
- \(P_{\max}\) al log-step = 1,000000;
- \(D_{\max}\) cresce di +1;
- \(C_{\max}\) scende di -0,415037.

Il log puro vede una discesa immediata, ma \(H\) riconosce che la traiettoria è ancora dentro un corridoio espansivo.

---

## 19. Caso con massima espansione

Il massimo rapporto osservato tra valore massimo e valore iniziale tra i peggioramenti fino a 20 milioni è:

\[
n=16.098.751
\]

con:

- max_ratio = 197.430,845;
- loss = 77;
- ratio \(v_2=1\) = 0,709677;
- \(P_{\max}\) al log-step = 1,000000;
- \(D_{\max}\) cresce di +7,300750.

Questo è un caso particolarmente chiaro di discesa locale ingannevole seguita da esplosione massiccia.

---

## 20. Interpretazione fisica aggiornata

La metafora fisica corretta non è semplicemente un buco nero unico.

È meglio descrivere il sistema come:

> una rete di corridoi espansivi sottili che confluisce in canali dissipativi ad alta densità di divisioni per 2.

In questa immagine:

- \(\log(n)\) è l'altitudine locale;
- \(D_{\max}\) è il debito gravitazionale futuro;
- \(C_{\max}\) è la presenza di una cascata di caduta;
- \(P_{\max}\) è la pressione del corridoio espansivo.

La funzione \(H\) misura se una massa numerica è davvero uscita dal campo pericoloso, non solo se ha perso quota momentaneamente.

---

## 21. Cosa manca per una dimostrazione

Questi risultati non costituiscono ancora una dimostrazione della Congettura di Collatz.

Per arrivare a una dimostrazione servirebbe provare almeno una delle seguenti affermazioni generali.

### A. Debito limitato

Esiste una funzione \(B(n)\) tale che per ogni orbita:

\[
D(k)\leq B(n)
\]

oppure, meglio, un limite strutturale indipendente dalla singola orbita.

### B. Confluenza obbligata

Ogni corridoio espansivo deve prima o poi confluire in un tronco dissipativo.

### C. Dominanza dei tronchi dissipativi

Ogni tronco sufficientemente profondo dell'albero inverso possiede una media \(v_2\) superiore a:

\[
\log_2(3)
\]

### D. Corridoi \(v_2=1\) non infiniti

Una pressione \(P_{\max}\) alta non può persistere indefinitamente senza generare una successiva cascata dissipativa.

### E. Funzione di Lyapunov corretta

Esiste una funzione:

\[
H(n)=\log n+R(n)
\]

Dove \(R(n)\) è un termine aritmetico 2-adico, tale che per ogni \(n>1\) esiste \(k\) con:

\[
H(S^k(n))<H(n)
\]

La funzione empirica:

\[
H(n)=\log(n)+0.28D_{\max,80}(n)-0.03C_{\max,80}(n)+0.30P_{\max,80}(n)
\]

è una possibile approssimazione computazionale di tale funzione.

---

## 22. Programma di ricerca

La porta teorica più interessante è dimostrare che:

> ogni corridoio con alta pressione \(P_{\max}\) genera inevitabilmente, dopo un tempo finito, una cascata \(C_{\max}\) sufficiente a compensare il debito \(D_{\max}\).

In forma intuitiva:

\[
\text{pressione espansiva}\Rightarrow\text{vincolo 2-adico}\Rightarrow\text{cascata dissipativa futura}
\]

Se questa implicazione venisse formalizzata, la teoria potrebbe avvicinarsi a una vera dimostrazione.

---

## 23. Conclusione

Il lavoro computazionale suggerisce una struttura non casuale:

1. le fasi espansive sono legate a sequenze con alta densità di \(v_2=1\);
2. tali sequenze corrispondono a corridoi 2-adici rari;
3. i corridoi espansivi non restano isolati;
4. confluiscono in tronchi comuni;
5. i tronchi comuni osservati sono fortemente dissipativi;
6. il collasso avviene quando il surplus \(v_2\) supera definitivamente il debito accumulato;
7. la funzione \(H\) riconosce molte discese locali ingannevoli;
8. i peggioramenti di \(H\) sono quasi sempre casi davvero instabili.

La metafora finale è:

\[
\boxed{
\text{una rete di corridoi espansivi 2-adici che accumula debito, confluisce e scarica energia in tronchi dissipativi.}
}
\]

Questa formulazione è più rigorosa della metafora iniziale del buco nero e può essere usata come programma di ricerca per una futura funzione di Lyapunov formale.
